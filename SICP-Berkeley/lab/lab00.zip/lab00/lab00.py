def twenty_fifteen():
    """Come up with the most creative expression that evaluates to 2015,
    using only numbers and the +, *, and - operators.

    >>> twenty_fifteen()
    2015
    """
    return ______
